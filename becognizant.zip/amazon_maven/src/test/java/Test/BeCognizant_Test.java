package Test;

import java.io.FileNotFoundException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASS.utilities;
import POM.home_page;
import POM.login_page;
import POM.signin_page;

public class BeCognizant_Test extends utilities {
	
	WebDriver dr;
	
	signin_page sp;
	login_page lp;
	home_page hp;
	
  @BeforeMethod
  public void bm() {
	  System.out.println("in TestNG");
	  System.setProperty("webdriver.chrome.driver","src\\test\\resources\\DRIVER\\chromedriver_v79.exe" );
	  dr=new ChromeDriver();
	  dr.get("https://be.cognizant.com/");
  }
  
  @Test(dataProvider="cts")
  public void test(String u,String un,String pas,String n1, String d1,String n)
  {
	  sp=new signin_page(dr);
	  lp=new login_page(dr);
	  hp=new home_page(dr);
	  
	  sp.umail(u);
	  lp.do_login(un, pas);
	  hp.in_homepage(n1, d1);
	  
	  String act_name=hp.get_name(n);
	  String exp_name=" Kumar, Kishore (Cognizant)";
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(act_name, exp_name);
	  
	  String act_des=hp.get_desgn(d1);
	  String exp_des=" Programmer Analyst Trainee";
	  SoftAssert sa1=new SoftAssert();
	  sa1.assertEquals(act_des, exp_des);

	  
  }
  
  @DataProvider(name="cts")
  public String[][] data_prov() throws FileNotFoundException 
  {
	  System.out.println("in data provider");
	  get_test_data();
		return testdata;
  }
  
  @AfterMethod
  public void am()
  {
	  dr.close();
  }
  
}
