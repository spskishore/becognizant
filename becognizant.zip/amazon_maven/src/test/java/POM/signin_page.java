package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class signin_page {

	
	By uid=By.xpath("//input[@id='i0116']");
	
	WebDriver dr;
	
	public signin_page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void umail(String umail)
	{
		dr.findElement(uid).sendKeys(umail);
	}
	
	
}
