package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class home_page {

	
	By name=By.xpath("//div[@class='media'][1]/div[2]/p");
	By designation=By.xpath("//div[@class='media'][1]/div[2]/span");
	By personalize=By.xpath("//span[@class='icomoon-user']");
	By add=By.xpath("//li[@class='personalise__add-more']/button");
	By enter=By.xpath("//input[@id='term-browser-3FC59F68-90EA-4B81-A5DF-38D01126EAF3Search']");
	WebDriver dr;
	
	public home_page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public String get_name(String na)
	{
		return dr.findElement(name).getText();
	}
	
	public String get_desgn(String de)
	{
		return dr.findElement(designation).getText();
	}
	
	public void personalize()
	{
		dr.findElement(personalize).click();
	}
	
	public void add()
	{
		dr.findElement(add).click();
	}
	
	
	public void acquisition(String ac)
	{
		dr.findElement(enter).sendKeys("acquisitions");
	}
	public void in_homepage(String n, String d)
	{
		this.get_name(n);
		this.get_desgn(d);
		this.personalize();
	}
	
}
