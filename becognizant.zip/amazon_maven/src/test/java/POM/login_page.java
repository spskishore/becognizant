package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login_page {

	
	By uid=By.xpath("//input[@id='userNameInput']");
	By pwd=By.xpath("//input[@id='passwordInput']");
	By login=By.xpath("//input[@id='Log_On1']");
	
	WebDriver dr;
	
	public login_page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void set_uid(String un)
	{
		String us=subString(1,7);
		System.out.println(us);
		dr.findElement(uid).sendKeys(us);
	}
	
	private String subString(int i, int j) {
		// TODO Auto-generated method stub
		return null;
	}

	public void set_pwd(String pd)
	{
		dr.findElement(pwd).sendKeys(pd);
	}
	
	public void set_login()
	{
		dr.findElement(login).click();
	}
	
	public void do_login(String u, String p)
	{
		this.set_uid(u);
		this.set_pwd(p);
		this.set_login();
	}
}
